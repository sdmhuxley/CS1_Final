import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner txtInput = new Scanner(System.in);
    Scanner numInput = new Scanner(System.in);
    int choice = 0;

    int food = 800;
    int wagonParts = 2;
    int money = 100;
    int ox = 2;
    int health1 = 100;
    int health2 = 100;
    int health3 = 100;
    int health4 = 100;
    boolean death1 = false;
    boolean death2 = false;
    boolean death3 = false;
    boolean death4 = false;
    int miles = 0;
    boolean sick1 = false;
    boolean sick2 = false;
    boolean sick3 = false;
    boolean sick4 = false;
    // ==============================================FAMILY
    // NAMES===================================================
    // ===============================================FLUSH
    // CODE=====================================================
    System.out.print("\033[H\033[2J");
    System.out.flush();
    // =========================================================================================================
    System.out.println("Welcome to the Oregon Trail");
    System.out.println("Please enter the first names of your 4 family members");
    int fam = 1;
    String name1 = "";
    String name2 = "";
    String name3 = "";
    String name4 = "";
    while (fam <= 4) {
      System.out.println("Enter a name:");
      if (fam == 1) {
        name1 = txtInput.nextLine();
      } else if (fam == 2) {
        name2 = txtInput.nextLine();
      } else if (fam == 3) {
        name3 = txtInput.nextLine();
      } else {
        name4 = txtInput.nextLine();
      }
      fam++;
    }
    // =============================================================================================================
    System.out.println("You have " + ox + " oxen, " + wagonParts + " wagon parts, " + food + " food, and $" + money + ".");
    // WAIT CODE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    try {
      Thread.sleep(6000);
    } catch (InterruptedException ex) {
      Thread.currentThread().interrupt();
    }
    // ===========================================================================================================================
    System.out.println("Would you like to visit the general store?\n1. Yes\n2. No");
    choice = numInput.nextInt();
    int choiceShop = 0;
    if (choice == 1) {
      while (choiceShop != 4 && money >= 0) {
        System.out.println("1. Buy 1 Oxen for $50");
        System.out.println("2. Buy 200 Food for $100");
        System.out.println("3. Buy 1 Wagon part for $10");
        System.out.println("4. Exit");
        choiceShop = numInput.nextInt();
        if (choiceShop == 1) {
          if (money < 50) {
            System.out.println("You don't have enough money");
          } else {
            ox++;
            money -= 50;
            System.out.println("You now have " + ox + " ox and $" + money);
          }
        } else if (choiceShop == 2) {
          if (money < 100) {
            System.out.println("You don't have enough money");
          } else {
            food += 200;
            money -= 100;
            System.out.println("You now have " + food + " food and $" + money);
          }
        } else if (choiceShop == 3) {
          if (money < 10) {
            System.out.println("You don't have enough money");
          } else {
            wagonParts++;
            money -= 10;
            System.out.println("You now have " + wagonParts + " wagon parts and $" + money);
          }
        } else
          System.out.println("Goodbye!");
      }
    }

    try {
      Thread.sleep(1000);
    } catch (InterruptedException ex) {
      Thread.currentThread().interrupt();
    }
    System.out.print("\033[H\033[2J");
    System.out.flush();

    System.out.println("Good luck " + name1 + ", " + name2 + ", " + name3 + ", and " + name4 + ", first stop, Fort Kearny");

    System.out.println("This will be a 100 mile trip");
  //===========================================================================================================================
    while (health1 > 0 || health2 > 0 || health3 > 0 || health4 > 0) {
      try {
        Thread.sleep(3000);
      } catch (InterruptedException ex) {
        Thread.currentThread().interrupt();
      }
      System.out.print("\033[H\033[2J");
      System.out.flush();
//=========================================================================================================================
      miles += 100;
      food -= 100;
       if (food <0)
      {
        System.out.println("You have no more food");
        break;
      }
      if (sick1 == true)
      {
        health1 -= 20;
        System.out.println(name1+"s symptoms have gotten worse...");
        if (health1 <= 0)
        {
          System.out.println(name1 +" died");
          death1 = true;
        }
      }
      else if (sick2 == true)
      {
        health2 -= 20;
        System.out.println(name2+"s symptoms have gotten worse...");
        if (health2 <= 0)
        {
          System.out.println(name2 +" died");
          death2 = true;
        }
      }
      else if (sick3 == true)
      {
        health3 -= 20;
        System.out.println(name3+"s symptoms have gotten worse...");
        if (health3 <= 0)
        {
          System.out.println(name3 +" died");
          death3 = true;
        }
      }
      else if (sick4 == true)
      {
        health4 -= 20;
        System.out.println(name4+"s symptoms have gotten worse...");
        if (health4 <= 0)
        {
          System.out.println(name4 +" died");
          death4 = true;
        }
      }
      else 
      {
        System.out.println("Luckily nobody was sick!");
      }
      System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      
      choice = numInput.nextInt();
      while (choice != 4)
        {
      if (choice == 1)
      {
        choiceShop = 0;
        while (choiceShop != 4 && money >= 0) {
        System.out.println("1. Buy 1 Oxen for $50");
        System.out.println("2. Buy 200 Food for $100");
        System.out.println("3. Buy 1 Wagon part for $10");
        System.out.println("4. Exit");
        choiceShop = numInput.nextInt();
        if (choiceShop == 1) {
          if (money < 50) {
            System.out.println("You don't have enough money");
          } else {
            ox++;
            money -= 50;
            System.out.println("You now have " + ox + " ox and $" + money);
          }
        } else if (choiceShop == 2) {
          if (money < 100) {
            System.out.println("You don't have enough money");
          } else {
            food += 200;
            money -= 100;
            System.out.println("You now have " + food + " food and $" + money);
          }
        } else if (choiceShop == 3) {
          if (money < 10) {
            System.out.println("You don't have enough money");
          } else {
            wagonParts++;
            money -= 10;
            System.out.println("You now have " + wagonParts + " wagon parts and $" + money);
          }
        } else
          System.out.println("Goodbye!");
      }
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 2)
      {
        if (health1 <= 90 && death1 == false)
        {
          health1 += 10;
        }
        if (health2 <= 90 && death2 == false)
        {
          health2 += 10;
        }
        if (health3 <= 90 && death3 == false)
        {
          health3 += 10;
        }
        if (health4 <= 90 && death4 == false)
        {
          health4 += 10;
        }
        System.out.println("You rest for a day. " + name1 +" is at "+ health1 + " health, " + name2 +" is at "+ health2 + " health, " + name3 +" is at "+ health3 + " health, and "+ name4 +" is at "+ health4 + " health.");

        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 3)
      {
        int rand = (int) (Math.random() * 3) + 1;
        if (rand == 1)
        {
          money -= 10;
          System.out.println("You loose $10, you now have $" + money);
        }
        else if (rand == 2)
        {
           money += 10;
          System.out.println("You found $10, you now have $" + money);
        }
        else if (rand == 3)
        {
           food += 100;
          System.out.println("A kind stranger gave you 100 food, you now have " + food + " food");
        }
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 5)
      {
        System.out.println("You have traveled " + miles + " miles, next town is Fort Laramie");
        System.out.println("You have " + wagonParts + " wagon part(s), " + food + " food, and $" + money);
        System.out.println(name1 +" is at "+ health1 + " health, " + name2 +" is at "+ health2 + " health, " + name3 +" is at "+ health3 + " health, and "+ name4 +" is at "+ health4 + " health.");
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else 
      {
        System.out.println("That is not an option");
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
        }
      System.out.println("Off to Laramie!");
      
       int rand = (int) (Math.random() * 9) + 1;
      int randName = (int) (Math.random() * 4) + 1;
      if (rand == 1) {
        // ================================================================================================================

        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      } 
      else if (rand == 2) {
        // ================================================================================================================

        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      }
      else if (rand == 3) {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      } 
      else if (rand == 4) {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println("Unfortunate. " + name1 + " tripped and hurt themselves");
          health1 -= 25;
          if (health1 <= 0)
        {
          System.out.println(name1 +" died");
          death1 = true;
        }
        } else if (randName == 2) {
          System.out.println("Unfortunate. " + name2 + " tripped and hurt themselves");
          health2 -= 25;
          if (health2 <= 0)
        {
          System.out.println(name2 +" died");
          death2 = true;
        }
        } else if (randName == 3) {
          System.out.println("Unfortunate. " + name3 + " tripped and hurt themselves");
          health3 -= 25;
          if (health3 <= 0)
        {
          System.out.println(name3 +" died");
          death3 = true;
        }
        } else {
          System.out.println("Unfortunate. " + name4 + " tripped and hurt themselves");
          health4 -= 25;
          if (health4 <= 0)
        {
          System.out.println(name4 +" died");
          death4 = true;
        }
        }
        // ================================================================================================================
      } 
      else if (rand == 5) {
        while (choice != 2) {
          System.out.println("A group of robbers sticks you up. \"Pay us or die!\"\n1. Pay them\2. Die");
          choice = numInput.nextInt();
          if (choice == 1) {
            System.out.println("The robbers force you to give them $100.");
            money -= 100;
          } else if (choice == 2) {
            System.out.println("\"Sorry buddy\"");
            health1 -= 100;
            health2 -= 100;
            health3 -= 100;
            health3 -= 100;
          } else {
            System.out.println("\"Stop stalling and give us your money\"");
          }
        }
      } 
      else if (rand == 6) {
        if (wagonParts >0)
        {
        System.out.println("Your wagon breaks! Luckily you have the parts to fix it.");
        }
        else 
        {
         System.out.println("Your wagon breaks! Unfortunately you are now stranded...");
          break;
        }
      } 
      else if (rand == 7) {
        System.out.println("Good Fortune! You found $50!");
        money += 50;
      } 
      else if (rand == 8) {
        if (sick1 == true) {
          System.out.println("Good Fortune! " + name1 + " has recovered from their sickness!");
        } else if (sick2 == true) {
          System.out.println("Good Fortune! " + name2 + " has recovered from their sickness!");
        }
        if (sick3 == true) {
          System.out.println("Good Fortune! " + name3 + " has recovered from their sickness!");
        }
        if (sick4 == true) {
          System.out.println("Good Fortune! " + name4 + " has recovered from their sickness!");
        }
      } 
      else {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println("Good Fortune! " + name1 + " has brought home food!");
          food += 100;
        } else if (randName == 2) {
          System.out.println("Good Fortune! " + name2 + " has brought home food!");
          food += 100;
        } else if (randName == 3) {
          System.out.println("Good Fortune! " + name3 + " has brought home food!");
          food += 100;
        } else {
          System.out.println("Good Fortune! " + name4 + " has brought home food!");
          food += 100;
        }
        // ================================================================================================================
      }
      try {
      Thread.sleep(2000);
    } catch (InterruptedException ex) {
      Thread.currentThread().interrupt();
    }
    System.out.print("\033[H\033[2J");
    System.out.flush();

    System.out.println("Welcome to Fort Laramie " + name1 + ", " + name2 + ", " + name3 + ", and " + name4 + "!");
  //===========================================================================================================================
//=========================================================================================================================
      miles += 100;
      food -= 100;
       if (food <0)
      {
        System.out.println("You have no more food");
        break;
      }
      if (sick1 == true)
      {
        health1 -= 20;
        System.out.println(name1+"s symptoms have gotten worse...");
        if (health1 <= 0)
        {
          System.out.println(name1 +" died");
          death1 = true;
        }
      }
      else if (sick2 == true)
      {
        health2 -= 20;
        System.out.println(name2+"s symptoms have gotten worse...");
        if (health2 <= 0)
        {
          System.out.println(name2 +" died");
          death2 = true;
        }
      }
      else if (sick3 == true)
      {
        health3 -= 20;
        System.out.println(name3+"s symptoms have gotten worse...");
        if (health3 <= 0)
        {
          System.out.println(name3 +" died");
          death3 = true;
        }
      }
      else if (sick4 == true)
      {
        health4 -= 20;
        System.out.println(name4+"s symptoms have gotten worse...");
        if (health4 <= 0)
        {
          System.out.println(name4 +" died");
          death4 = true;
        }
      }
      else 
      {
        System.out.println("Luckily nobody was sick!");
      }
      System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      while (choice != 4)
        {
      if (choice == 1)
      {
        choiceShop = 0;
        while (choiceShop != 4 && money >= 0) {
        System.out.println("1. Buy 1 Oxen for $50");
        System.out.println("2. Buy 200 Food for $100");
        System.out.println("3. Buy 1 Wagon part for $10");
        System.out.println("4. Exit");
        choiceShop = numInput.nextInt();
        if (choiceShop == 1) {
          if (money < 50) {
            System.out.println("You don't have enough money");
          } else {
            ox++;
            money -= 50;
            System.out.println("You now have " + ox + " ox and $" + money);
          }
        } else if (choiceShop == 2) {
          if (money < 100) {
            System.out.println("You don't have enough money");
          } else {
            food += 200;
            money -= 100;
            System.out.println("You now have " + food + " food and $" + money);
          }
        } else if (choiceShop == 3) {
          if (money < 10) {
            System.out.println("You don't have enough money");
          } else {
            wagonParts++;
            money -= 10;
            System.out.println("You now have " + wagonParts + " wagon parts and $" + money);
          }
        } else
          System.out.println("Goodbye!");
      }
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 2)
      {
        if (health1 <= 90 && death1 == false)
        {
          health1 += 10;
        }
        if (health2 <= 90 && death2 ==false)
        {
          health2 += 10;
        }
        if (health3 <= 90 && death3 == false)
        {
          health3 += 10;
        }
        if (health4 <= 90 && death4 == false)
        {
          health4 += 10;
        }
        System.out.println("You rest for a day. " + name1 +" is at "+ health1 + " health, " + name2 +" is at "+ health2 + " health, " + name3 +" is at "+ health3 + " health, and "+ name4 +" is at "+ health4 + " health.");

        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 3)
      {
         rand = (int) (Math.random() * 3) + 1;
        if (rand == 1)
        {
          money -= 10;
          System.out.println("You loose $10, you now have $" + money);
        }
        else if (rand == 2)
        {
           money += 10;
          System.out.println("You found $10, you now have $" + money);
        }
        else if (rand == 3)
        {
           food += 100;
          System.out.println("A kind stranger gave you 100 food, you now have " + food + " food");
        }
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 5)
      {
        System.out.println("You have traveled " + miles + " miles, next town is Fort Bridger");
        System.out.println("You have " + wagonParts + " wagon part(s), " + food + " food, and $" + money);
        System.out.println(name1 +" is at "+ health1 + " health, " + name2 +" is at "+ health2 + " health, " + name3 +" is at "+ health3 + " health, and "+ name4 +" is at "+ health4 + " health.");
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else 
      {
        System.out.println("That is not an option");
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
        }
      System.out.println("Off to Bridger!");
     
        rand = (int) (Math.random() * 9) + 1;
       randName = (int) (Math.random() * 4) + 1;
      if (rand == 1) {
        // ================================================================================================================

        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      } 
      else if (rand == 2) {
        // ================================================================================================================

        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      }
      else if (rand == 3) {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      } 
      else if (rand == 4) {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println("Unfortunate. " + name1 + " tripped and hurt themselves");
          health1 -= 25;
          if (health1 <= 0)
        {
          System.out.println(name1 +" died");
          death1 = true;
        }
        } else if (randName == 2) {
          System.out.println("Unfortunate. " + name2 + " tripped and hurt themselves");
          health2 -= 25;
          if (health2 <= 0)
        {
          System.out.println(name2 +" died");
          death2 = true;
        }
        } else if (randName == 3) {
          System.out.println("Unfortunate. " + name3 + " tripped and hurt themselves");
          health3 -= 25;
          if (health3 <= 0)
        {
          System.out.println(name3 +" died");
          death3 = true;
        }
        } else {
          System.out.println("Unfortunate. " + name4 + " tripped and hurt themselves");
          health4 -= 25;
          if (health4 <= 0)
        {
          System.out.println(name4 +" died");
          death4 = true;
        }
        }
        // ================================================================================================================
      } 
      else if (rand == 5) {
        while (choice != 2) {
          System.out.println("A group of robbers sticks you up. \"Pay us or die!\"\n1. Pay them\2. Die");
          choice = numInput.nextInt();
          if (choice == 1) {
            System.out.println("The robbers force you to give them $100.");
            money -= 100;
          } else if (choice == 2) {
            System.out.println("\"Sorry buddy\"");
            health1 -= 100;
            health2 -= 100;
            health3 -= 100;
            health3 -= 100;
          } else {
            System.out.println("\"Stop stalling and give us your money\"");
          }
        }
      } 
      else if (rand == 6) {
        if (wagonParts >0)
        {
        System.out.println("Your wagon breaks! Luckily you have the parts to fix it.");
        }
        else 
        {
         System.out.println("Your wagon breaks! Unfortunately you are now stranded...");
          break;
        }
      } 
      else if (rand == 7) {
        System.out.println("Good Fortune! You found $50!");
        money += 50;
      } 
      else if (rand == 8) {
        if (sick1 == true) {
          System.out.println("Good Fortune! " + name1 + " has recovered from their sickness!");
        } else if (sick2 == true) {
          System.out.println("Good Fortune! " + name2 + " has recovered from their sickness!");
        }
        if (sick3 == true) {
          System.out.println("Good Fortune! " + name3 + " has recovered from their sickness!");
        }
        if (sick4 == true) {
          System.out.println("Good Fortune! " + name4 + " has recovered from their sickness!");
        }
      } 
      else {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println("Good Fortune! " + name1 + " has brought home food!");
          food += 100;
        } else if (randName == 2) {
          System.out.println("Good Fortune! " + name2 + " has brought home food!");
          food += 100;
        } else if (randName == 3) {
          System.out.println("Good Fortune! " + name3 + " has brought home food!");
          food += 100;
        } else {
          System.out.println("Good Fortune! " + name4 + " has brought home food!");
          food += 100;
        }
        // ================================================================================================================
      }
      miles += 150;
      food -= 150;
       if (food <0)
      {
        System.out.println("You have no more food");
        break;
      }
      if (sick1 == true)
      {
        health1 -= 20;
        System.out.println(name1+"s symptoms have gotten worse...");
        if (health1 <= 0)
        {
          System.out.println(name1 +" died");
          death1 = true;
        }
      }
      else if (sick2 ==true)
      {
        health2 -= 20;
        System.out.println(name2+"s symptoms have gotten worse...");
        if (health2 <= 0)
        {
          System.out.println(name2 +" died");
          death2 = true;
        }
      }
      else if (sick3 ==true)
      {
        health3 -= 20;
        System.out.println(name3+"s symptoms have gotten worse...");
        if (health3 <= 0)
        {
          System.out.println(name3 +" died");
          death3 = true;
        }
      }
      else if (sick4 ==true)
      {
        health4 -= 20;
        System.out.println(name4+"s symptoms have gotten worse...");
        if (health4 <= 0)
        {
          System.out.println(name4 +" died");
          death4 = true;
        }
      }
      else 
      {
        System.out.println("Luckily nobody was sick!");
      }
      System.out.println("Welcome to Fort Bridger " + name1 + ", " + name2 + ", " + name3 + ", and " + name4 + "!");
      System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      while (choice != 4)
        {
      if (choice == 1)
      {
        choiceShop = 0;
        while (choiceShop != 4 && money >= 0) {
        System.out.println("1. Buy 1 Oxen for $50");
        System.out.println("2. Buy 200 Food for $100");
        System.out.println("3. Buy 1 Wagon part for $10");
        System.out.println("4. Exit");
        choiceShop = numInput.nextInt();
        if (choiceShop == 1) {
          if (money < 50) {
            System.out.println("You don't have enough money");
          } else {
            ox++;
            money -= 50;
            System.out.println("You now have " + ox + " ox and $" + money);
          }
        } else if (choiceShop == 2) {
          if (money < 100) {
            System.out.println("You don't have enough money");
          } else {
            food += 200;
            money -= 100;
            System.out.println("You now have " + food + " food and $" + money);
          }
        } else if (choiceShop == 3) {
          if (money < 10) {
            System.out.println("You don't have enough money");
          } else {
            wagonParts++;
            money -= 10;
            System.out.println("You now have " + wagonParts + " wagon parts and $" + money);
          }
        } else
          System.out.println("Goodbye!");
      }
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 2)
      {
        if (health1 <= 90 && death1 == false)
        {
          health1 += 10;
        }
        if (health2 <= 90 && death2 == false)
        {
          health2 += 10;
        }
        if (health3 <= 90 && death3 == false)
        {
          health3 += 10;
        }
        if (health4 <= 90 && death4 == false)
        {
          health4 += 10;
        }
        System.out.println("You rest for a day. " + name1 +" is at "+ health1 + " health, " + name2 +" is at "+ health2 + " health, " + name3 +" is at "+ health3 + " health, and "+ name4 +" is at "+ health4 + " health.");

        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 3)
      {
         rand = (int) (Math.random() * 3) + 1;
        if (rand == 1)
        {
          money -= 10;
          System.out.println("You loose $10, you now have $" + money);
        }
        else if (rand == 2)
        {
           money += 10;
          System.out.println("You found $10, you now have $" + money);
        }
        else if (rand == 3)
        {
           food += 100;
          System.out.println("A kind stranger gave you 100 food, you now have " + food + " food");
        }
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 5)
      {
        System.out.println("You have traveled " + miles + " miles, next town is Fort Hall");
        System.out.println("You have " + wagonParts + " wagon part(s), " + food + " food, and $" + money);
        System.out.println(name1 +" is at "+ health1 + " health, " + name2 +" is at "+ health2 + " health, " + name3 +" is at "+ health3 + " health, and "+ name4 +" is at "+ health4 + " health.");
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else 
      {
        System.out.println("That is not an option");
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
        }
      System.out.println("Off to Hall!");

      rand = (int) (Math.random() * 9) + 1;
       randName = (int) (Math.random() * 4) + 1;
     if (rand == 1) {
        // ================================================================================================================

        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      } 
      else if (rand == 2) {
        // ================================================================================================================

        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      }
      else if (rand == 3) {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      } 
      else if (rand == 4) {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println("Unfortunate. " + name1 + " tripped and hurt themselves");
          health1 -= 25;
          if (health1 <= 0)
        {
          System.out.println(name1 +" died");
          death1 = true;
        }
        } else if (randName == 2) {
          System.out.println("Unfortunate. " + name2 + " tripped and hurt themselves");
          health2 -= 25;
          if (health2 <= 0)
        {
          System.out.println(name2 +" died");
          death2 = true;
        }
        } else if (randName == 3) {
          System.out.println("Unfortunate. " + name3 + " tripped and hurt themselves");
          health3 -= 25;
          if (health3 <= 0)
        {
          System.out.println(name3 +" died");
          death3 = true;
        }
        } else {
          System.out.println("Unfortunate. " + name4 + " tripped and hurt themselves");
          health4 -= 25;
          if (health4 <= 0)
        {
          System.out.println(name4 +" died");
          death4 = true;
        }
        }
        // ================================================================================================================
      } 
      else if (rand == 5) {
        while (choice != 2) {
          System.out.println("A group of robbers sticks you up. \"Pay us or die!\"\n1. Pay them\2. Die");
          choice = numInput.nextInt();
          if (choice == 1) {
            System.out.println("The robbers force you to give them $100.");
            money -= 100;
          } else if (choice == 2) {
            System.out.println("\"Sorry buddy\"");
            health1 -= 100;
            health2 -= 100;
            health3 -= 100;
            health3 -= 100;
          } else {
            System.out.println("\"Stop stalling and give us your money\"");
          }
        }
      } 
      else if (rand == 6) {
        if (wagonParts >0)
        {
        System.out.println("Your wagon breaks! Luckily you have the parts to fix it.");
        }
        else 
        {
         System.out.println("Your wagon breaks! Unfortunately you are now stranded...");
          break;
        }
      } 
      else if (rand == 7) {
        System.out.println("Good Fortune! You found $50!");
        money += 50;
      } 
      else if (rand == 8) {
        if (sick1 == true) {
          System.out.println("Good Fortune! " + name1 + " has recovered from their sickness!");
        } else if (sick2 == true) {
          System.out.println("Good Fortune! " + name2 + " has recovered from their sickness!");
        }
        if (sick3 == true) {
          System.out.println("Good Fortune! " + name3 + " has recovered from their sickness!");
        }
        if (sick4 == true) {
          System.out.println("Good Fortune! " + name4 + " has recovered from their sickness!");
        }
      } 
      else {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println("Good Fortune! " + name1 + " has brought home food!");
          food += 100;
        } else if (randName == 2) {
          System.out.println("Good Fortune! " + name2 + " has brought home food!");
          food += 100;
        } else if (randName == 3) {
          System.out.println("Good Fortune! " + name3 + " has brought home food!");
          food += 100;
        } else {
          System.out.println("Good Fortune! " + name4 + " has brought home food!");
          food += 100;
        }
        // ================================================================================================================
      }
      miles += 100;
      food -= 100;
       if (food <0)
      {
        System.out.println("You have no more food");
        break;
      }
      if (sick1 == true)
      {
        health1 -= 20;
        System.out.println(name1+"s symptoms have gotten worse...");
        if (health1 <= 0)
        {
          System.out.println(name1 +" died");
          death1 = true;
        }
      }
      else if (sick2 ==true)
      {
        health2 -= 20;
        System.out.println(name2+"s symptoms have gotten worse...");
        if (health2 <= 0)
        {
          System.out.println(name2 +" died");
          death2 = true;
        }
      }
      else if (sick3 ==true)
      {
        health3 -= 20;
        System.out.println(name3+"s symptoms have gotten worse...");
        if (health3 <= 0)
        {
          System.out.println(name3 +" died");
          death3 = true;
        }
      }
      else if (sick4 ==true)
      {
        health4 -= 20;
        System.out.println(name4+"s symptoms have gotten worse...");
        if (health4 <= 0)
        {
          System.out.println(name4 +" died");
          death4 = true;
        }
      }
      else 
      {
        System.out.println("Luckily nobody was sick!");
      }
      System.out.println("Welcome to Fort Hall " + name1 + ", " + name2 + ", " + name3 + ", and " + name4 + "!");
      System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      while (choice != 4)
        {
      if (choice == 1)
      {
        choiceShop = 0;
        while (choiceShop != 4 && money >= 0) {
        System.out.println("1. Buy 1 Oxen for $50");
        System.out.println("2. Buy 200 Food for $100");
        System.out.println("3. Buy 1 Wagon part for $10");
        System.out.println("4. Exit");
        choiceShop = numInput.nextInt();
        if (choiceShop == 1) {
          if (money < 50) {
            System.out.println("You don't have enough money");
          } else {
            ox++;
            money -= 50;
            System.out.println("You now have " + ox + " ox and $" + money);
          }
        } else if (choiceShop == 2) {
          if (money < 100) {
            System.out.println("You don't have enough money");
          } else {
            food += 200;
            money -= 100;
            System.out.println("You now have " + food + " food and $" + money);
          }
        } else if (choiceShop == 3) {
          if (money < 10) {
            System.out.println("You don't have enough money");
          } else {
            wagonParts++;
            money -= 10;
            System.out.println("You now have " + wagonParts + " wagon parts and $" + money);
          }
        } else
          System.out.println("Goodbye!");
      }
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 2)
      {
        if (health1 <= 90 && death1 == false)
        {
          health1 += 10;
        }
        if (health2 <= 90 && death2 == false)
        {
          health2 += 10;
        }
        if (health3 <= 90 && death3 == false)
        {
          health3 += 10;
        }
        if (health4 <= 90 && death4 == false)
        {
          health4 += 10;
        }
        System.out.println("You rest for a day. " + name1 +" is at "+ health1 + " health, " + name2 +" is at "+ health2 + " health, " + name3 +" is at "+ health3 + " health, and "+ name4 +" is at "+ health4 + " health.");

        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 3)
      {
         rand = (int) (Math.random() * 3) + 1;
        if (rand == 1)
        {
          money -= 10;
          System.out.println("You loose $10, you now have $" + money);
        }
        else if (rand == 2)
        {
           money += 10;
          System.out.println("You found $10, you now have $" + money);
        }
        else if (rand == 3)
        {
           food += 100;
          System.out.println("A kind stranger gave you 100 food, you now have " + food + " food");
        }
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 5)
      {
        System.out.println("You have traveled " + miles + " miles, next town is Fort Boise");
        System.out.println("You have " + wagonParts + " wagon part(s), " + food + " food, and $" + money);
        System.out.println(name1 +" is at "+ health1 + " health, " + name2 +" is at "+ health2 + " health, " + name3 +" is at "+ health3 + " health, and "+ name4 +" is at "+ health4 + " health.");
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else 
      {
        System.out.println("That is not an option");
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
        }
      System.out.println("Off to Boise!");

      rand = (int) (Math.random() * 9) + 1;
       randName = (int) (Math.random() * 4) + 1;
      if (rand == 1) {
        // ================================================================================================================

        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      } 
      else if (rand == 2) {
        // ================================================================================================================

        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      }
      else if (rand == 3) {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      } 
      else if (rand == 4) {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println("Unfortunate. " + name1 + " tripped and hurt themselves");
          health1 -= 25;
          if (health1 <= 0)
        {
          System.out.println(name1 +" died");
          death1 = true;
        }
        } else if (randName == 2) {
          System.out.println("Unfortunate. " + name2 + " tripped and hurt themselves");
          health2 -= 25;
          if (health2 <= 0)
        {
          System.out.println(name2 +" died");
          death2 = true;
        }
        } else if (randName == 3) {
          System.out.println("Unfortunate. " + name3 + " tripped and hurt themselves");
          health3 -= 25;
          if (health3 <= 0)
        {
          System.out.println(name3 +" died");
          death3 = true;
        }
        } else {
          System.out.println("Unfortunate. " + name4 + " tripped and hurt themselves");
          health4 -= 25;
          if (health4 <= 0)
        {
          System.out.println(name4 +" died");
          death4 = true;
        }
        }
        // ================================================================================================================
      } 
      else if (rand == 5) {
        while (choice != 2) {
          System.out.println("A group of robbers sticks you up. \"Pay us or die!\"\n1. Pay them\2. Die");
          choice = numInput.nextInt();
          if (choice == 1) {
            System.out.println("The robbers force you to give them $100.");
            money -= 100;
          } else if (choice == 2) {
            System.out.println("\"Sorry buddy\"");
            health1 -= 100;
            health2 -= 100;
            health3 -= 100;
            health3 -= 100;
          } else {
            System.out.println("\"Stop stalling and give us your money\"");
          }
        }
      } 
      else if (rand == 6) {
        if (wagonParts >0)
        {
        System.out.println("Your wagon breaks! Luckily you have the parts to fix it.");
        }
        else 
        {
         System.out.println("Your wagon breaks! Unfortunately you are now stranded...");
          break;
        }
      } 
      else if (rand == 7) {
        System.out.println("Good Fortune! You found $50!");
        money += 50;
      } 
      else if (rand == 8) {
        if (sick1 == true) {
          System.out.println("Good Fortune! " + name1 + " has recovered from their sickness!");
        } else if (sick2 == true) {
          System.out.println("Good Fortune! " + name2 + " has recovered from their sickness!");
        }
        if (sick3 == true) {
          System.out.println("Good Fortune! " + name3 + " has recovered from their sickness!");
        }
        if (sick4 == true) {
          System.out.println("Good Fortune! " + name4 + " has recovered from their sickness!");
        }
      } 
      else {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println("Good Fortune! " + name1 + " has brought home food!");
          food += 100;
        } else if (randName == 2) {
          System.out.println("Good Fortune! " + name2 + " has brought home food!");
          food += 100;
        } else if (randName == 3) {
          System.out.println("Good Fortune! " + name3 + " has brought home food!");
          food += 100;
        } else {
          System.out.println("Good Fortune! " + name4 + " has brought home food!");
          food += 100;
        }
        // ================================================================================================================
      }
      miles += 100;
      food -= 100;
       if (food <0)
      {
        System.out.println("You have no more food");
        break;
      }
      if (sick1 == true)
      {
        health1 -= 20;
        System.out.println(name1+"s symptoms have gotten worse...");
        if (health1 <= 0)
        {
          System.out.println(name1 +" died");
          death1 = true;
        }
      }
      else if (sick2 ==true)
      {
        health2 -= 20;
        System.out.println(name2+"s symptoms have gotten worse...");
        if (health2 <= 0)
        {
          System.out.println(name2 +" died");
          death2 = true;
        }
      }
      else if (sick3 ==true)
      {
        health3 -= 20;
        System.out.println(name3+"s symptoms have gotten worse...");
        if (health3 <= 0)
        {
          System.out.println(name3 +" died");
          death3 = true;
        }
      }
      else if (sick4 ==true)
      {
        health4 -= 20;
        System.out.println(name4+"s symptoms have gotten worse...");
        if (health4 <= 0)
        {
          System.out.println(name4 +" died");
          death4 = true;
        }
      }
      else 
      {
        System.out.println("Luckily nobody was sick!");
      }
      System.out.println("Welcome to Fort Boise " + name1 + ", " + name2 + ", " + name3 + ", and " + name4 + "!");
      System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      while (choice != 4)
        {
      if (choice == 1)
      {
        choiceShop = 0;
        while (choiceShop != 4 && money >= 0) {
        System.out.println("1. Buy 1 Oxen for $50");
        System.out.println("2. Buy 200 Food for $100");
        System.out.println("3. Buy 1 Wagon part for $10");
        System.out.println("4. Exit");
        choiceShop = numInput.nextInt();
        if (choiceShop == 1) {
          if (money < 50) {
            System.out.println("You don't have enough money");
          } else {
            ox++;
            money -= 50;
            System.out.println("You now have " + ox + " ox and $" + money);
          }
        } else if (choiceShop == 2) {
          if (money < 100) {
            System.out.println("You don't have enough money");
          } else {
            food += 200;
            money -= 100;
            System.out.println("You now have " + food + " food and $" + money);
          }
        } else if (choiceShop == 3) {
          if (money < 10) {
            System.out.println("You don't have enough money");
          } else {
            wagonParts++;
            money -= 10;
            System.out.println("You now have " + wagonParts + " wagon parts and $" + money);
          }
        } else
          System.out.println("Goodbye!");
      }
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 2)
      {
        if (health1 <= 90 && death1 == false)
        {
          health1 += 10;
        }
        if (health2 <= 90 && death2 == false)
        {
          health2 += 10;
        }
        if (health3 <= 90 && death3 == false)
        {
          health3 += 10;
        }
        if (health4 <= 90 && death4 == false)
        {
          health4 += 10;
        }
        System.out.println("You rest for a day. " + name1 +" is at "+ health1 + " health, " + name2 +" is at "+ health2 + " health, " + name3 +" is at "+ health3 + " health, and "+ name4 +" is at "+ health4 + " health.");

        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 3)
      {
         rand = (int) (Math.random() * 3) + 1;
        if (rand == 1)
        {
          money -= 10;
          System.out.println("You loose $10, you now have $" + money);
        }
        else if (rand == 2)
        {
           money += 10;
          System.out.println("You found $10, you now have $" + money);
        }
        else if (rand == 3)
        {
           food += 100;
          System.out.println("A kind stranger gave you 100 food, you now have " + food + " food");
        }
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 5)
      {
        System.out.println("You have traveled " + miles + " miles, next town is Fort Vancouver");
        System.out.println("You have " + wagonParts + " wagon part(s), " + food + " food, and $" + money);
        System.out.println(name1 +" is at "+ health1 + " health, " + name2 +" is at "+ health2 + " health, " + name3 +" is at "+ health3 + " health, and "+ name4 +" is at "+ health4 + " health.");
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else 
      {
        System.out.println("That is not an option");
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
        }
      System.out.println("Off to Vancouver!");

      rand = (int) (Math.random() * 9) + 1;
       randName = (int) (Math.random() * 4) + 1;
      if (rand == 1) {
        // ================================================================================================================

        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      } 
      else if (rand == 2) {
        // ================================================================================================================

        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      }
      else if (rand == 3) {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      } 
      else if (rand == 4) {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println("Unfortunate. " + name1 + " tripped and hurt themselves");
          health1 -= 25;
          if (health1 <= 0)
        {
          System.out.println(name1 +" died");
          death1 = true;
        }
        } else if (randName == 2) {
          System.out.println("Unfortunate. " + name2 + " tripped and hurt themselves");
          health2 -= 25;
          if (health2 <= 0)
        {
          System.out.println(name2 +" died");
          death2 = true;
        }
        } else if (randName == 3) {
          System.out.println("Unfortunate. " + name3 + " tripped and hurt themselves");
          health3 -= 25;
          if (health3 <= 0)
        {
          System.out.println(name3 +" died");
          death3 = true;
        }
        } else {
          System.out.println("Unfortunate. " + name4 + " tripped and hurt themselves");
          health4 -= 25;
          if (health4 <= 0)
        {
          System.out.println(name4 +" died");
          death4 = true;
        }
        }
        // ================================================================================================================
      } 
      else if (rand == 5) {
        while (choice != 2) {
          System.out.println("A group of robbers sticks you up. \"Pay us or die!\"\n1. Pay them\2. Die");
          choice = numInput.nextInt();
          if (choice == 1) {
            System.out.println("The robbers force you to give them $100.");
            money -= 100;
          } else if (choice == 2) {
            System.out.println("\"Sorry buddy\"");
            health1 -= 100;
            health2 -= 100;
            health3 -= 100;
            health3 -= 100;
          } else {
            System.out.println("\"Stop stalling and give us your money\"");
          }
        }
      } 
      else if (rand == 6) {
        if (wagonParts >0)
        {
        System.out.println("Your wagon breaks! Luckily you have the parts to fix it.");
        }
        else 
        {
         System.out.println("Your wagon breaks! Unfortunately you are now stranded...");
          break;
        }
      } 
      else if (rand == 7) {
        System.out.println("Good Fortune! You found $50!");
        money += 50;
      } 
      else if (rand == 8) {
        if (sick1 == true) {
          System.out.println("Good Fortune! " + name1 + " has recovered from their sickness!");
        } else if (sick2 == true) {
          System.out.println("Good Fortune! " + name2 + " has recovered from their sickness!");
        }
        if (sick3 == true) {
          System.out.println("Good Fortune! " + name3 + " has recovered from their sickness!");
        }
        if (sick4 == true) {
          System.out.println("Good Fortune! " + name4 + " has recovered from their sickness!");
        }
      } 
      else {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println("Good Fortune! " + name1 + " has brought home food!");
          food += 100;
        } else if (randName == 2) {
          System.out.println("Good Fortune! " + name2 + " has brought home food!");
          food += 100;
        } else if (randName == 3) {
          System.out.println("Good Fortune! " + name3 + " has brought home food!");
          food += 100;
        } else {
          System.out.println("Good Fortune! " + name4 + " has brought home food!");
          food += 100;
        }
        // ================================================================================================================
      }
      miles += 100;
      food -= 100;
       if (food <0)
      {
        System.out.println("You have no more food");
        break;
      }
      if (sick1 == true)
      {
        health1 -= 20;
        System.out.println(name1+"s symptoms have gotten worse...");
        if (health1 <= 0)
        {
          System.out.println(name1 +" died");
          death1 = true;
        }
      }
      else if (sick2 ==true)
      {
        health2 -= 20;
        System.out.println(name2+"s symptoms have gotten worse...");
        if (health2 <= 0)
        {
          System.out.println(name2 +" died");
          death2 = true;
        }
      }
      else if (sick3 ==true)
      {
        health3 -= 20;
        System.out.println(name3+"s symptoms have gotten worse...");
        if (health3 <= 0)
        {
          System.out.println(name3 +" died");
          death3 = true;
        }
      }
      else if (sick4 ==true)
      {
        health4 -= 20;
        System.out.println(name4+"s symptoms have gotten worse...");
        if (health4 <= 0)
        {
          System.out.println(name4 +" died");
          death4 = true;
        }
      }
      else 
      {
        System.out.println("Luckily nobody was sick!");
      }
      System.out.println("Welcome to Fort Vancouver " + name1 + ", " + name2 + ", " + name3 + ", and " + name4 + "!");
      System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      while (choice != 4)
        {
      if (choice == 1)
      {
        choiceShop = 0;
        while (choiceShop != 4 && money >= 0) {
        System.out.println("1. Buy 1 Oxen for $50");
        System.out.println("2. Buy 200 Food for $100");
        System.out.println("3. Buy 1 Wagon part for $10");
        System.out.println("4. Exit");
        choiceShop = numInput.nextInt();
        if (choiceShop == 1) {
          if (money < 50) {
            System.out.println("You don't have enough money");
          } else {
            ox++;
            money -= 50;
            System.out.println("You now have " + ox + " ox and $" + money);
          }
        } else if (choiceShop == 2) {
          if (money < 100) {
            System.out.println("You don't have enough money");
          } else {
            food += 200;
            money -= 100;
            System.out.println("You now have " + food + " food and $" + money);
          }
        } else if (choiceShop == 3) {
          if (money < 10) {
            System.out.println("You don't have enough money");
          } else {
            wagonParts++;
            money -= 10;
            System.out.println("You now have " + wagonParts + " wagon parts and $" + money);
          }
        } else
          System.out.println("Goodbye!");
      }
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 2)
      {
        if (health1 <= 90 && death1 == false)
        {
          health1 += 10;
        }
        if (health2 <= 90 && death2 == false)
        {
          health2 += 10;
        }
        if (health3 <= 90 && death3 == false)
        {
          health3 += 10;
        }
        if (health4 <= 90 && death4 == false)
        {
          health4 += 10;
        }
        System.out.println("You rest for a day. " + name1 +" is at "+ health1 + " health, " + name2 +" is at "+ health2 + " health, " + name3 +" is at "+ health3 + " health, and "+ name4 +" is at "+ health4 + " health.");

        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 3)
      {
         rand = (int) (Math.random() * 3) + 1;
        if (rand == 1)
        {
          money -= 10;
          System.out.println("You loose $10, you now have $" + money);
        }
        else if (rand == 2)
        {
           money += 10;
          System.out.println("You found $10, you now have $" + money);
        }
        else if (rand == 3)
        {
           food += 100;
          System.out.println("A kind stranger gave you 100 food, you now have " + food + " food");
        }
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else if (choice == 5)
      {
        System.out.println("You have traveled " + miles + " miles, you're almost there!");
        System.out.println("You have " + wagonParts + " wagon part(s), " + food + " food, and $" + money);
        System.out.println(name1 +" is at "+ health1 + " health, " + name2 +" is at "+ health2 + " health, " + name3 +" is at "+ health3 + " health, and "+ name4 +" is at "+ health4 + " health.");
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
      else 
      {
        System.out.println("That is not an option");
        System.out.println("1. Buy supplies\n2. Rest\n3. Explore\n4. Advance to the next town\n5. Check progress");
      choice = numInput.nextInt();
      }
        }
      System.out.println("Off to Oregon! Only 50 miles left");
      rand = (int) (Math.random() * 9) + 1;
       randName = (int) (Math.random() * 4) + 1;
      if (rand == 1) {
        // ================================================================================================================

        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      } 
      else if (rand == 2) {
        // ================================================================================================================

        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
        // ================================================================================================================
      }
      else if (rand == 3) {
        // ================================================================================================================
        randName = ((int) Math.random() * 4) + 1;
        if (randName == 1) {
          System.out.println(name1
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick1 = true;
        } else if (randName == 2) {
          System.out.println(name2
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick2 = true;
        } else if (randName == 3) {
          System.out.println(name3
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick3 = true;
        } else {
          System.out.println(name4
              + " has contracted a disease, they can recieve help in the next town if you can make it in time...");
          sick4 = true;
        }
      }
    }
  }
}
  
        // ======== 